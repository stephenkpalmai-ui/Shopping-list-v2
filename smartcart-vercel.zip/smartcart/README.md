# 🛒 SmartCart

Find the best grocery prices near you, powered by AI.

---

## Why This Exists

The original version called the Anthropic API directly from the browser, which works locally but gets blocked by CORS security when hosted publicly (like on GitHub Pages). This version adds a small **backend proxy** that lives on Vercel — your API key stays safe on the server, and the browser talks to your proxy instead.

```
Browser → /api/chat (your Vercel proxy) → Anthropic API
```

---

## Project Structure

```
smartcart/
├── api/
│   └── chat.js        ← Serverless proxy function (runs on Vercel)
├── public/
│   └── index.html     ← Your frontend app
├── vercel.json        ← Tells Vercel how to route requests
└── README.md
```

---

## Deploy to Vercel (Step by Step)

### Step 1 — Get a free Vercel account
Go to [vercel.com](https://vercel.com) and sign up with your GitHub account.

### Step 2 — Push this project to GitHub
If you haven't already:
1. Create a new repo on github.com (call it `smartcart`)
2. Upload all these files maintaining the folder structure above

### Step 3 — Import into Vercel
1. Go to [vercel.com/new](https://vercel.com/new)
2. Click **"Import Git Repository"**
3. Select your `smartcart` repo
4. Click **Deploy** — don't change any settings

### Step 4 — Add your API key (important!)
This is the step that makes it actually work:
1. In Vercel, go to your project → **Settings** → **Environment Variables**
2. Add a new variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your Anthropic API key (starts with `sk-ant-...`)
3. Click **Save**
4. Go to **Deployments** and click **Redeploy** so it picks up the new key

### Step 5 — Open your live URL
Vercel gives you a URL like `https://smartcart-yourname.vercel.app` — open it and it should work!

---

## Add to Your Phone Home Screen

Once deployed:

**iPhone (Safari):**
1. Open your Vercel URL in Safari
2. Tap the Share button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Tap **Add** — it now lives on your home screen like an app

**Android (Chrome):**
1. Open your Vercel URL in Chrome
2. Tap the three dots menu
3. Tap **"Add to Home Screen"**

---

## Getting Your Anthropic API Key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign in (use same account as Claude Pro)
3. Go to **API Keys** → **Create Key**
4. Copy it and paste into Vercel as described above

> ⚠️ Note: API usage on the console is separate from your Claude Pro subscription and has its own usage-based billing. For light personal use it costs just a few cents per session.

---

## Future Ideas (Your v2 Backlog)

- [ ] Connect to Kroger API for real-time prices
- [ ] Connect to Walmart API
- [ ] "Split my list" mode — buy each item from its cheapest store
- [ ] Save favorite lists
- [ ] Push notifications for sales on saved items
- [ ] PWA mode for full offline support
